"""설날 vs 추석, 어느 명절이 더 위험한가 — Streamlit 대시보드

실행:
    pip install -r requirements.txt
    streamlit run app.py

화면 구성 (와이어프레임 기준) — 사이드바 '메뉴'에서 전환
    [명절 교통사고 대시보드]
    ① 전체 비교: VS 핵심 지표 → 연도별 비교 · 치사율 → 연휴 일자별 추이 → 지도(+사고다발지) · 시도 순위 → 인사이트
    ② 연도 상세: 일자별 상세표 · 시군구 TOP 10 → 요일별 비교 · 한 줄 요약
    [보험 FAQ] 보험사 영역 → 보험 항목 영역 → 검색 → FAQ 목록 (faq.py)
"""
from __future__ import annotations

import json

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from analysis import (
    GEO_PATH,
    HOLIDAYS,
    HOTSPOT_PERIOD,
    METRICS,
    WEEKDAYS,
    day_table,
    day_trend,
    filter_years,
    hotspot_area_stats,
    hotspot_values,
    hotspots_in,
    insights,
    josa,
    load_data,
    load_hotspots,
    previous_year_summary,
    region_rows,
    sgg_list,
    sgg_top,
    sido_compare,
    sido_list,
    summarize,
    verdict,
    weekday_compare,
    yearly,
)
from faq import render_faq

# ---------------------------------------------------------------- 기본 설정
st.set_page_config(page_title="명절 교통사고 · 보험 FAQ", layout="wide")

COLORS = {"설날": "#E9B200", "추석": "#1D2630"}  # 설날 = 노랑, 추석 = 먹색 (기존 HTML과 동일)
RED = "#C4302B"   # 사고다발지 점 · 판정 강조 전용 (지도 면 색에는 쓰지 않음)
BLUE = "#2F5D8A"  # 지도에서 사망 지표 색 (빨간 점과 겹치지 않도록)
UP, DOWN = "#C4302B", "#2F5D8A"  # 전년 대비 증가(나쁨) / 감소
MUTED = "#5B6570"
FONT = "Pretendard, 'Apple SD Gothic Neo', 'Malgun Gothic', 'IBM Plex Sans KR', sans-serif"
SOURCE = "출처: 도로교통공단, 설날·추석 연휴기간 사고통계(2021~2025), 연휴기간 사고다발지역(2021~2025)"

st.markdown(
    f"""
<style>
.vs-wrap {{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;height:100%;
          text-align:center;padding-top:28px}}
.vs-badge {{width:64px;height:64px;border-radius:50%;background:#1D2630;color:#fff;display:flex;
           align-items:center;justify-content:center;font-weight:800;font-size:22px}}
.verdict {{border:2px solid {RED};border-radius:8px;padding:8px 10px;font-weight:700;font-size:18px}}
.small-muted {{font-size:12px;color:{MUTED};line-height:1.5}}
.swatch {{display:inline-block;width:14px;height:14px;border-radius:3px;margin-right:6px;vertical-align:-1px}}
.insight-tag {{font-family:monospace;font-size:12px;color:{RED}}}
.summary-line {{font-size:22px;font-weight:700;line-height:1.5;margin:4px 0 12px}}
.fr-row {{margin:14px 0 18px}}
.fr-head {{display:flex;justify-content:space-between;align-items:baseline;font-size:15px}}
.fr-val {{font-size:24px;font-weight:800;font-variant-numeric:tabular-nums}}
.fr-track {{height:14px;background:#E3E0D8;border-radius:3px;margin:6px 0 4px;overflow:hidden}}
.fr-fill {{height:100%;border-radius:3px}}
.fr-sub {{font-size:12px;color:{MUTED}}}
.kpi-wrap {{container-type:inline-size}}
.kpi-grid {{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px 16px;margin-top:6px}}
@container (max-width:470px) {{.kpi-grid {{grid-template-columns:repeat(2,minmax(0,1fr))}}}}
.kpi-l {{font-size:13px;color:{MUTED}}}
.kpi-v {{font-size:clamp(22px,2.1vw,32px);font-weight:700;line-height:1.25;white-space:nowrap;
        font-variant-numeric:tabular-nums;letter-spacing:-0.02em}}
.kpi-v small {{font-size:14px;font-weight:500;color:{MUTED};margin-left:2px}}
.kpi-d {{font-size:12px;font-weight:600;white-space:nowrap}}
</style>
""",
    unsafe_allow_html=True,
)


@st.cache_data
def get_data() -> pd.DataFrame:
    return load_data()


@st.cache_data
def get_hotspots() -> pd.DataFrame:
    return load_hotspots()


@st.cache_data
def get_geo() -> dict:
    with open(GEO_PATH, encoding="utf-8") as f:
        return json.load(f)


def style(fig: go.Figure, height: int = 320, legend: bool = True) -> go.Figure:
    fig.update_layout(
        height=height,
        margin=dict(l=10, r=10, t=10, b=10),
        font=dict(family=FONT, size=13),
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        showlegend=legend,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0, title=None),
        hoverlabel=dict(font_family=FONT),
    )
    fig.update_xaxes(showgrid=False)
    fig.update_yaxes(gridcolor="#E3E0D8", zeroline=False)
    return fig


def md(text: str) -> str:
    """마크다운에서 ~A~ 가 취소선으로 바뀌지 않도록 물결표를 이스케이프합니다.

    st.caption / st.markdown / st.write / 라벨은 마크다운으로 렌더링되므로
    '2021~2025' 처럼 물결표가 들어간 문구는 꼭 md()로 감싸서 넘기세요.
    """
    return text.replace("~", r"\~")


def fmt(v: float, per_day: bool = False) -> str:
    return f"{v:,.1f}" if per_day else f"{v:,.0f}"


df = get_data()
geo = get_geo()
hotspots = get_hotspots()
YEARS = sorted(int(y) for y in df["연도"].unique())
PERIOD = f"{YEARS[0]}~{YEARS[-1]}"

# ---------------------------------------------------------------- 사이드바 메뉴
PAGES = ["명절 교통사고 대시보드", "보험 FAQ"]
with st.sidebar:
    page = st.radio("메뉴", PAGES, key="page")
    st.divider()

if page == "보험 FAQ":
    render_faq(st)
    st.stop()

# ---------------------------------------------------------------- 사이드바 필터
with st.sidebar:
    st.header("조건")
    year_label = st.selectbox("연도", [f"전체 ({PERIOD})"] + [f"{y}년" for y in YEARS])
    year = None if year_label.startswith("전체") else int(year_label[:4])
    metric = st.radio("지표", list(METRICS), horizontal=True, format_func=lambda m: f"{m}({METRICS[m]})")
    per_day = st.toggle("일평균으로 보정 (연휴 길이 차이 반영)", value=True)
    st.divider()
    sido = st.selectbox("시도", ["전체"] + sido_list(df))
    sgg = st.selectbox("시군구", ["전체"] + sgg_list(df, sido), disabled=sido == "전체")
    st.divider()
    st.caption(md(
        "사고는 건수, 부상·사망은 사람 수입니다. 부상자 수에는 중상자가 포함됩니다. "
        "연휴 기간은 해마다 3~5일로 달라서 비교할 때는 일평균을 함께 보세요."
    ))
    st.caption(md(SOURCE))

unit = METRICS[metric]
where = "전국" if sido == "전체" else (sido if sgg == "전체" else f"{sido} {sgg}")
basis = "일평균" if per_day else "합계"

rows = region_rows(df, sido, sgg)          # 선택 지역, 모든 연도
cur = filter_years(rows, year)             # 선택 지역, 선택 연도
summary = summarize(cur)
prev = previous_year_summary(rows, year)
vd = verdict(summary, metric, per_day)

# ---------------------------------------------------------------- 헤더
st.title("설날 vs 추석, 어느 명절이 더 위험한가")
st.caption(md(f"명절 연휴 교통사고 비교 · {year_label} · {where}"))

tab_all, tab_detail = st.tabs(["① 전체 비교", "② 연도 상세"])

# ================================================================= ① 전체 비교
with tab_all:
    # --- VS 핵심 지표
    def kpi_panel(h: str) -> None:
        with st.container(border=True):
            st.markdown(
                f"<h4 style='margin:0'><span class='swatch' style='background:{COLORS[h]}'></span>{h} 연휴</h4>",
                unsafe_allow_html=True,
            )
            st.caption(md(f"연휴 {int(summary.loc[h, '일수'])}일" + ("" if year else f" ({PERIOD} 합계)")))
            items = [("사고", "사고", "건"), ("사망", "사망", "명"), ("부상", "부상", "명"), ("일평균 사고", "사고_일평균", "건")]
            tiles = []
            for label, key, u in items:
                val = summary.loc[h, key]
                delta_html = ""
                if prev is not None:
                    base = prev.loc[h, key]
                    d = val - base
                    color = UP if d > 0 else DOWN if d < 0 else MUTED
                    arrow = "▲" if d > 0 else "▼" if d < 0 else "–"
                    pct = f" ({d / base * 100:+.1f}%)" if base else ""
                    delta_html = f"<div class='kpi-d' style='color:{color}'>{arrow} {abs(d):,.0f}{u}{pct}</div>"
                tiles.append(
                    f"<div><div class='kpi-l'>{label}</div>"
                    f"<div class='kpi-v'>{val:,.0f}<small>{u}</small></div>{delta_html}</div>"
                )
            st.markdown(f"<div class='kpi-wrap'><div class='kpi-grid'>{''.join(tiles)}</div></div>", unsafe_allow_html=True)
            if year and prev is None:
                st.caption("비교할 이전 해 자료가 없습니다.")
            elif prev is not None:
                st.caption(f"증감은 {year - 1}년 대비")

    left, mid, right = st.columns([5, 1.3, 5])
    with left:
        kpi_panel("설날")
    with right:
        kpi_panel("추석")
    with mid:
        if vd["winner"]:
            ratio_txt = "상대 명절은 0" if vd["ratio"] == float("inf") else f"{vd['ratio']:.0f}% 더 많음"
            verdict_html = f"<div class='verdict' style='color:{RED}'>{vd['winner']}</div><div class='small-muted'>{metric} {basis} 기준<br>{ratio_txt}</div>"
        else:
            verdict_html = "<div class='verdict'>같음</div>"
        st.markdown(
            f"<div class='vs-wrap'><div class='vs-badge'>VS</div><div class='small-muted'>더 위험한 명절</div>{verdict_html}</div>",
            unsafe_allow_html=True,
        )

    # --- 연도별 비교 · 치사율
    c1, c2 = st.columns([2, 1])
    with c1:
        with st.container(border=True):
            st.subheader(f"연도별 {metric} {basis}", divider=False)
            yt = yearly(rows, metric, per_day)
            fig = go.Figure()
            for h in HOLIDAYS:
                t = yt[yt["명절"] == h]
                fig.add_bar(
                    name=h,
                    x=t["연도"].astype(str) + "년",
                    y=t["값"],
                    marker_color=COLORS[h],
                    marker_opacity=[1 if (year is None or y == year) else 0.3 for y in t["연도"]],
                    customdata=t["일수"],
                    hovertemplate=f"{h} %{{x}}<br>{metric} %{{y:,.{1 if per_day else 0}f}}{unit}<br>연휴 %{{customdata}}일<extra></extra>",
                )
            fig.update_layout(barmode="group", bargap=0.3)
            st.plotly_chart(style(fig), use_container_width=True)
            st.caption("선택한 연도는 진하게 표시됩니다. 막대에 마우스를 올리면 연휴 일수를 볼 수 있습니다.")
    with c2:
        with st.container(border=True):
            st.subheader("치사율 비교", divider=False)
            fr_max = max(summary["치사율"].max(), 0.01)
            for h in HOLIDAYS:
                rate = summary.loc[h, "치사율"]
                dead, acc = int(summary.loc[h, "사망"]), int(summary.loc[h, "사고"])
                width = rate / fr_max * 100
                st.markdown(
                    f"<div class='fr-row'><div class='fr-head'><span><span class='swatch' style='background:{COLORS[h]}'></span>{h}</span>"
                    f"<span class='fr-val'>{rate:.2f}</span></div>"
                    f"<div class='fr-track'><div class='fr-fill' style='width:{width:.1f}%;background:{COLORS[h]}'></div></div>"
                    f"<div class='fr-sub'>사망 {dead:,}명 ÷ 사고 {acc:,}건 × 100</div></div>",
                    unsafe_allow_html=True,
                )
            st.caption("사고 100건당 사망자 수입니다. 건수는 적어도 더 치명적인 명절이 있는지 보는 보조 지표입니다.")
            zero = [h for h in HOLIDAYS if summary.loc[h, "사망"] == 0 and summary.loc[h, "사고"] > 0]
            if zero:
                st.caption(f"{'·'.join(zero)} 연휴에는 이 조건에서 사망자가 0명이라 치사율이 0입니다.")
            if 0 < summary["사망"].min() < 5 or zero:
                st.caption("사망자가 적은 지역·연도는 한두 명 차이로 치사율이 크게 흔들리니 5년 전체나 전국 기준으로 함께 보세요.")

    # --- 연휴 일자별 추이
    with st.container(border=True):
        st.subheader("연휴 일자별 추이 — 연휴 초반과 후반, 언제 더 위험한가", divider=False)
        dt = day_trend(cur, metric)
        fig = go.Figure()
        for h in HOLIDAYS:
            t = dt[dt["명절"] == h]
            fig.add_scatter(
                name=h,
                x=t["일차명"],
                y=t["값"],
                mode="lines+markers",
                line=dict(color=COLORS[h], width=3, dash="solid" if h == "설날" else "dash"),
                marker=dict(size=8),
                customdata=t["연도수"],
                hovertemplate=f"{h} %{{x}}<br>{metric} %{{y:,.1f}}{unit}<br>%{{customdata}}개 연도 평균<extra></extra>"
                if year is None
                else f"{h} %{{x}}<br>{metric} %{{y:,.0f}}{unit}<extra></extra>",
            )
        order = [f"{i}일차" for i in sorted(dt["일차"].unique())]
        fig.update_xaxes(categoryorder="array", categoryarray=order)
        st.plotly_chart(style(fig, 300), use_container_width=True)
        st.caption(
            "연휴 첫날을 1일차로 맞춰 정렬했습니다. "
            + ("여러 해를 합친 경우 같은 일차끼리 평균이며, 4·5일차는 연휴가 긴 해만 들어갑니다." if year is None else "")
        )

    # --- 지도 · 시도 순위
    sc = sido_compare(df, year, metric, per_day)
    c1, c2 = st.columns(2)
    with c1:
        with st.container(border=True):
            st.subheader("지역별 지도", divider=False)
            m1, m2 = st.columns([3, 2])
            mode = m1.radio("지도 색", ["설날+추석", "추석 − 설날", "설날", "추석"], horizontal=True, label_visibility="collapsed")
            show_hs = m2.toggle(md(f"사고다발지 표시 ({HOTSPOT_PERIOD})"), value=True)
            sc_map = sc.assign(**{"설날+추석": sc["설날"] + sc["추석"]})
            hover = {"설날": ":,.1f", "추석": ":,.1f"}
            if mode == "추석 − 설날":
                lim = max(abs(sc_map["차이"]).max(), 1e-9)
                fig = px.choropleth(
                    sc_map, geojson=geo, locations="시도", featureidkey="properties.n", color="차이",
                    color_continuous_scale=[[0, "#B98700"], [0.5, "#F4F4F0"], [1, "#1D2630"]],
                    range_color=[-lim, lim], hover_data={**hover, "차이": ":+,.1f"},
                )
                legend_note = "노랑 = 설날이 더 많음 · 먹색 = 추석이 더 많음"
            else:
                high = BLUE if metric == "사망" else ("#E9B200" if mode == "설날+추석" else COLORS[mode])
                fig = px.choropleth(
                    sc_map, geojson=geo, locations="시도", featureidkey="properties.n", color=mode,
                    color_continuous_scale=[[0, "#FFFFFF"], [1, high]], hover_data=hover,
                )
                legend_note = f"진할수록 {mode} {metric} 많음"
            fig.update_traces(marker_line_color="#C3C9C1", marker_line_width=0.6)  # 시도 경계선
            if sido != "전체":  # 선택한 시도 테두리 강조
                fig.add_trace(
                    go.Choropleth(
                        geojson=geo, locations=[sido], z=[0], featureidkey="properties.n",
                        colorscale=[[0, "rgba(0,0,0,0)"], [1, "rgba(0,0,0,0)"]], showscale=False,
                        marker_line_color="#1D2630", marker_line_width=2.5, hoverinfo="skip",
                    )
                )
            hs_view = hotspots_in(hotspots, sido, sgg)
            if show_hs and not hs_view.empty:
                # 점 크기와 툴팁 첫 줄은 사이드바에서 고른 지표를 따릅니다.
                hv = hotspot_area_stats(df, hs_view, year, metric).assign(
                    값=hotspot_values(hs_view, metric).to_numpy(),
                    부상자=hotspot_values(hs_view, "부상").to_numpy(),
                )
                area_label = f"{year}년" if year else PERIOD
                vmax = max(hotspot_values(hotspots, metric).max(), 1)   # 전체 지점 기준 → 지역을 바꿔도 크기 비교 가능
                has = hv["값"] > 0
                fig.add_trace(
                    go.Scattergeo(
                        lon=hv["경도"], lat=hv["위도"], mode="markers",
                        marker=dict(
                            size=6 + 16 * (hv["값"] / vmax) ** 0.5,
                            color=[RED if x else "#FFFFFF" for x in has],     # 값이 0이면 속이 빈 점
                            opacity=0.9,
                            line=dict(color=[("#FFFFFF" if x else RED) for x in has], width=1.5),
                        ),
                        customdata=hv[["지점명", "값", "사고", "부상자", "사망", "시군구_기준", "지역_설날", "지역_추석"]],
                        hovertemplate=(
                            f"<b>%{{customdata[0]}}</b><br><b>{metric} %{{customdata[1]:,}}{unit}</b>"
                            "<br>사고 %{customdata[2]}건 · 부상 %{customdata[3]}명 · 사망 %{customdata[4]}명"
                            f"<br><span style='font-size:11px'>지점 수치는 {HOTSPOT_PERIOD} 합계 (연도·명절 구분 없음)</span>"
                            f"<br>── 소속 %{{customdata[5]}} {area_label} 연휴 {metric} ──"
                            f"<br>설날 %{{customdata[6]:,.0f}}{unit} · 추석 %{{customdata[7]:,.0f}}{unit}<extra></extra>"
                        ),
                        showlegend=False,
                    )
                )
            fig.update_geos(fitbounds="locations", visible=False, bgcolor="rgba(0,0,0,0)")
            fig.update_layout(coloraxis_colorbar=dict(title=None, thickness=10, len=0.6))
            st.plotly_chart(style(fig, 520, legend=False), use_container_width=True)
            st.caption(md(f"{legend_note}. {year_label}, {metric} {basis} 기준."))
            if show_hs:
                st.caption(md(
                    f"빨간 점 = 연휴 사고다발지 {len(hs_view)}곳. 점 크기는 선택한 지표({metric})를 따르며"
                    + (f", 속이 빈 점은 사망 0명인 지점입니다 ({int((hotspot_values(hs_view, '사망') > 0).sum())}곳만 사망 발생)." if metric == "사망" else ".")
                    + f" 지점 수치는 {HOTSPOT_PERIOD} 합계라 연도에 따라 바뀌지 않고, 연도 필터는 툴팁 아래쪽의 '소속 시군구 연휴 수치'에 적용됩니다."
                ))
    with c2:
        with st.container(border=True):
            st.subheader("시·도 순위", divider=False)
            table = sc.copy()
            table.insert(0, "순위", range(1, len(table) + 1))
            num_fmt = "%.1f" if per_day else "%d"
            st.dataframe(
                table,
                hide_index=True,
                use_container_width=True,
                height=530,
                column_config={
                    "설날": st.column_config.NumberColumn(f"설날 ({unit})", format=num_fmt),
                    "추석": st.column_config.NumberColumn(f"추석 ({unit})", format=num_fmt),
                    "차이": st.column_config.NumberColumn("차이 (추석−설날)", format="%+.1f" if per_day else "%+d"),
                },
            )
            st.caption("열 머리를 누르면 정렬됩니다. 기본 정렬은 추석이 설날보다 많은 순서입니다.")

    # --- 사고다발지 표
    with st.expander(md(f"연휴 사고다발지 목록 ({where} {len(hotspots_in(hotspots, sido, sgg))}곳 · {HOTSPOT_PERIOD} 묶음)")):
        hs_tab = hotspots_in(hotspots, sido, sgg)
        hs_tab = hotspot_area_stats(df, hs_tab, year, metric).assign(_v=hotspot_values(hs_tab, metric).to_numpy())
        hs_tab = hs_tab.sort_values(["_v", "사고", "사상자"], ascending=False)
        if hs_tab.empty:
            st.info(f"{where}에는 연휴 사고다발지가 없습니다.")
        else:
            yr = f"{year}년" if year else PERIOD
            col_s, col_c = f"소속 시군구 {yr} 설날 {metric}", f"소속 시군구 {yr} 추석 {metric}"
            st.dataframe(
                hs_tab.assign(지역=hs_tab["시도"] + " " + hs_tab["시군구"])
                .rename(columns={"지역_설날": col_s, "지역_추석": col_c})[
                    ["지점명", "지역", "사고", "사상자", "사망", "중상", "경상", "부상신고", col_s, col_c]
                ],
                hide_index=True,
                use_container_width=True,
                column_config={
                    col_s: st.column_config.NumberColumn(col_s, format="%d"),
                    col_c: st.column_config.NumberColumn(col_c, format="%d"),
                },
            )
        st.caption(md(
            f"사고~부상신고 열은 도로교통공단 연휴기간 사고다발지역({HOTSPOT_PERIOD} 합계)이라 연도에 따라 바뀌지 않습니다. "
            f"오른쪽 두 열은 지점이 속한 시군구의 연휴 사고통계로, 연도 필터에 따라 바뀝니다. 선택한 지표({metric})가 많은 지점부터 보여 줍니다."
        ))

    # --- 인사이트
    st.subheader("핵심 인사이트", divider=False)
    st.caption(md(f"{where} · {PERIOD} 전체 기준 · 지표: {metric}"))
    for i, (col, card) in enumerate(zip(st.columns(3), insights(rows, metric)), start=1):
        with col:
            with st.container(border=True):
                st.markdown(f"<span class='insight-tag'>INSIGHT 0{i}</span>", unsafe_allow_html=True)
                st.markdown(md(f"**{card['title']}**"))
                st.markdown(md(card["body"]))

# ================================================================= ② 연도 상세
with tab_detail:
    detail_year = st.radio(
        "연도 선택", YEARS, index=YEARS.index(year) if year else len(YEARS) - 1,
        horizontal=True, format_func=lambda y: f"{y}년",
    )
    st.header(f"{detail_year}년 설날 vs 추석 · {where}", divider="gray")

    c1, c2 = st.columns(2)
    with c1:
        with st.container(border=True):
            st.subheader("일자별 상세표", divider=False)
            dtab = day_table(rows, detail_year, metric)
            total = {"일차": "합계", "설날 날짜": "", "추석 날짜": "",
                     f"설날 {metric}": dtab[f"설날 {metric}"].sum(), f"추석 {metric}": dtab[f"추석 {metric}"].sum()}
            dtab = pd.concat([dtab, pd.DataFrame([total])], ignore_index=True)
            st.dataframe(dtab, hide_index=True, use_container_width=True)
            st.download_button(
                "CSV 내보내기",
                dtab.to_csv(index=False).encode("utf-8-sig"),
                file_name=f"{detail_year}_설날_추석_{metric}_{where}.csv",
                mime="text/csv",
            )
    with c2:
        with st.container(border=True):
            top_scope = "전국" if sido == "전체" else sido
            st.subheader(f"시군구 TOP 10 ({top_scope})", divider=False)
            top = sgg_top(df, detail_year, metric, sido)
            if top.empty or top["합계"].sum() == 0:
                st.info("이 조건에는 자료가 없습니다.")
            else:
                fig = go.Figure()
                for h in HOLIDAYS:
                    fig.add_bar(
                        name=h, y=top["지역"], x=top[h], orientation="h", marker_color=COLORS[h],
                        hovertemplate=f"%{{y}}<br>{h} {metric} %{{x:,}}{unit}<extra></extra>",
                    )
                fig.update_layout(barmode="stack")
                fig.update_yaxes(autorange="reversed", gridcolor="rgba(0,0,0,0)")
                st.plotly_chart(style(fig, 360), use_container_width=True)
                st.caption("설날 + 추석 합계 순. 시도를 고르면 그 시도 안의 순위를 보여 줍니다.")

    c3, c4 = st.columns(2)
    with c3:
        with st.container(border=True):
            st.subheader("요일별 하루 평균", divider=False)
            wk = weekday_compare(rows, metric)
            fig = go.Figure()
            for h in HOLIDAYS:
                t = wk[wk["명절"] == h]
                fig.add_bar(
                    name=h, x=t["요일"].astype(str), y=t["값"], marker_color=COLORS[h], customdata=t["일수"],
                    hovertemplate=f"{h} %{{x}}요일<br>하루 평균 {metric} %{{y:,.1f}}{unit}<br>%{{customdata}}일 평균<extra></extra>",
                )
            fig.update_layout(barmode="group")
            fig.update_xaxes(categoryorder="array", categoryarray=WEEKDAYS)
            st.plotly_chart(style(fig, 300), use_container_width=True)
            st.caption(md(f"{PERIOD} 전체 기준입니다. 한 해의 연휴는 3~5일뿐이라 요일 비교는 5년을 합쳐서 봅니다. 요일마다 들어간 날 수가 달라 하루 평균으로 비교합니다."))
    with c4:
        with st.container(border=True):
            st.subheader("이 해의 한 줄 요약", divider=False)
            sy = summarize(filter_years(rows, detail_year))
            vy = verdict(sy, metric, per_day=True)
            if vy["winner"]:
                ratio_txt = "" if vy["ratio"] == float("inf") else f" {vy['ratio']:.0f}%"
                line = f"{detail_year}년은 {josa(vy['winner'])} 일평균 {metric} 기준{ratio_txt} 더 위험했습니다."
            else:
                line = f"{detail_year}년은 두 명절의 일평균 {josa(metric)} 같았습니다."
            st.markdown(f"<div class='summary-line'>{line}</div>", unsafe_allow_html=True)
            py = previous_year_summary(rows, detail_year)
            for h in HOLIDAYS:
                txt = (f"- **{h}** 연휴 {int(sy.loc[h, '일수'])}일 · 일평균 {metric} {sy.loc[h, f'{metric}_일평균']:,.1f}{unit}"
                       f" · 치사율 {sy.loc[h, '치사율']:.2f}")
                if py is not None and py.loc[h, f"{metric}_일평균"]:
                    chg = (sy.loc[h, f"{metric}_일평균"] / py.loc[h, f"{metric}_일평균"] - 1) * 100
                    txt += f" · 전년 대비 {chg:+.1f}%"
                st.markdown(txt)

st.divider()
st.caption(md(f"{SOURCE}. ※ 인용 표기는 팀 DataFact 데이터 인용 가이드 형식에 맞춰 수정하세요."))
