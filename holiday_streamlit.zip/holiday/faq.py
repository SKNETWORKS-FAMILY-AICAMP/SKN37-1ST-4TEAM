"""보험 FAQ 한눈에 보기 — 보험사 4곳의 자주 묻는 질문을 한 화면에서 비교합니다.

app.py 사이드바에서 '보험 FAQ' 메뉴를 고르면 render_faq()가 화면을 그립니다.
데이터 정리 함수(load_faq)는 streamlit 없이도 쓸 수 있습니다.
    python faq.py
"""
from __future__ import annotations

import html
import re
from pathlib import Path

import pandas as pd

FAQ_DIR = Path(__file__).parent / "data" / "faq"

# 파일 · 표시 이름 · 분류 컬럼 (보험사마다 컬럼 이름이 달라 맞춰 줍니다)
INSURERS = {
    "삼성화재": ("samsungfire_faq.csv", "질문분류"),
    "AXA손해보험": ("axa_faq.csv", "질문분류"),
    "하나손해보험": ("hana_faq.csv", "항목"),
    "KB손해보험": ("kb_faq.csv", "항목"),
}
ALL = "전체"
PAGE_SIZE = 15


# ---------------------------------------------------------------- 데이터 정리
def clean_text(s: str) -> str:
    """CSV 저장 과정에서 쉼표가 공백으로 바뀐 부분 등을 되돌립니다."""
    s = str(s).replace("\r\n", "\n")
    s = html.unescape(s.replace("& #", "&#"))                 # '& #39;' → '
    s = re.sub(r"(?<=\d) (?=\d{3}(?!\d))", ",", s)            # 5 000만원 → 5,000만원
    s = re.sub(r"(?<=[^\s.]) {2,3}(?=\S)", ", ", s)            # '고객님  고객님께서' → '고객님, 고객님께서'
    s = re.sub(r"[ \t]{2,}", " ", s)                          # 남은 여분 공백
    return s.strip()


def load_faq(faq_dir: Path | str = FAQ_DIR) -> pd.DataFrame:
    """보험사 4곳 FAQ를 합쳐 [보험사, 항목, 질문, 답변] 표로 돌려줍니다."""
    frames = []
    for insurer, (fname, cat_col) in INSURERS.items():
        d = pd.read_csv(Path(faq_dir) / fname, encoding="utf-8-sig")
        d = d.rename(columns={cat_col: "항목"})[["항목", "질문", "답변"]]
        d["항목"] = d["항목"].fillna("미분류").astype(str).str.strip()
        d["질문"] = d["질문"].map(clean_text).str.replace(r"^Q\.\s*", "", regex=True)
        d["답변"] = d["답변"].map(clean_text).str.replace(r"^A\.\s*", "", regex=True)
        d = d.drop_duplicates(subset=["질문", "답변"])
        d.insert(0, "보험사", insurer)
        frames.append(d)
    return pd.concat(frames, ignore_index=True)


def categories(faq: pd.DataFrame, insurer: str) -> list[str]:
    """보험사의 항목 목록 (FAQ가 많은 항목부터)."""
    d = faq if insurer == ALL else faq[faq["보험사"] == insurer]
    return d["항목"].value_counts().index.tolist()


def filter_faq(faq: pd.DataFrame, insurer: str, category: str, query: str = "") -> pd.DataFrame:
    d = faq
    if insurer != ALL:
        d = d[d["보험사"] == insurer]
    if category != ALL:
        d = d[d["항목"] == category]
    q = query.strip()
    if q:
        d = d[d["질문"].str.contains(q, case=False, regex=False) | d["답변"].str.contains(q, case=False, regex=False)]
    return d


def md_escape(text: str) -> str:
    """expander 라벨처럼 마크다운으로 그려지는 곳에 넣을 때 특수문자를 이스케이프합니다."""
    return re.sub(r"([\\`*_{}\[\]()#+\-.!|~$>])", r"\\\1", text)


# ---------------------------------------------------------------- 화면
CSS = """
<style>
.faq-hero {background:#1D2630;color:#fff;border-radius:10px;padding:26px 28px;margin:4px 0 18px}
.faq-hero h1 {margin:0;font-size:30px;line-height:1.3;color:#fff}
.faq-hero h1 span {background:#E9B200;color:#1D2630;padding:0 .2em}
.faq-hero p {margin:6px 0 0;font-size:14px;color:#C9CED3}
.faq-sec {font-size:18px;font-weight:700;color:#2F5D8A;margin:18px 0 8px}
.faq-sec small {font-size:13px;font-weight:500;color:#5B6570;margin-left:6px}
.faq-a {font-size:15px;line-height:1.75;color:#1D2630;white-space:normal;word-break:keep-all}
.faq-meta {font-size:12px;color:#5B6570;margin-bottom:6px}
</style>
"""


def _button_grid(st, labels: list[str], selected: str, key: str, on_pick, per_row: int, counts: dict[str, int]):
    """선택된 버튼은 진하게(primary) 표시되는 버튼 묶음."""
    for start in range(0, len(labels), per_row):
        cols = st.columns(per_row)
        for col, label in zip(cols, labels[start:start + per_row]):
            col.button(
                f"{label} · {counts.get(label, 0)}",
                key=f"{key}_{label}",
                type="primary" if label == selected else "secondary",
                use_container_width=True,
                on_click=on_pick,
                args=(label,),
            )


def render_faq(st) -> None:
    """보험 FAQ 화면. app.py에서 render_faq(st)로 부릅니다."""
    faq = _load_cached(st)
    ss = st.session_state
    ss.setdefault("faq_insurer", ALL)
    ss.setdefault("faq_category", ALL)
    ss.setdefault("faq_page", 1)

    def pick_insurer(v):
        ss.faq_insurer, ss.faq_category, ss.faq_page = v, ALL, 1

    def pick_category(v):
        ss.faq_category, ss.faq_page = v, 1

    st.markdown(CSS, unsafe_allow_html=True)
    st.markdown(
        "<div class='faq-hero'><h1>보험 FAQ <span>한눈에 보기</span></h1>"
        f"<p>보험사 {len(INSURERS)}곳 · 자주 묻는 질문 {len(faq):,}개를 보험사와 항목별로 비교합니다.</p></div>",
        unsafe_allow_html=True,
    )

    # --- 보험사 영역
    st.markdown("<div class='faq-sec'>보험사 영역</div>", unsafe_allow_html=True)
    ins_counts = {ALL: len(faq), **faq["보험사"].value_counts().to_dict()}
    _button_grid(st, [ALL, *INSURERS], ss.faq_insurer, "ins", pick_insurer, per_row=5, counts=ins_counts)

    # --- 보험 항목 영역
    cats = categories(faq, ss.faq_insurer)
    if ss.faq_category not in [ALL, *cats]:
        ss.faq_category = ALL
    base = faq if ss.faq_insurer == ALL else faq[faq["보험사"] == ss.faq_insurer]
    cat_counts = {ALL: len(base), **base["항목"].value_counts().to_dict()}
    st.markdown(
        f"<div class='faq-sec'>보험 항목 영역<small>{html.escape(ss.faq_insurer)} · 항목 {len(cats)}개</small></div>",
        unsafe_allow_html=True,
    )
    _button_grid(st, [ALL, *cats], ss.faq_category, f"cat_{ss.faq_insurer}", pick_category, per_row=4, counts=cat_counts)

    # --- 검색
    query = st.text_input("질문 검색", placeholder="예: 자기부담금, 긴급출동, 해지", key="faq_query")
    if ss.get("_faq_last_query") != query:
        ss._faq_last_query, ss.faq_page = query, 1

    # --- FAQ 목록
    rows = filter_faq(faq, ss.faq_insurer, ss.faq_category, query)
    st.markdown(
        f"<div class='faq-sec'>자주 묻는 질문 (FAQ)<small>{len(rows):,}건</small></div>",
        unsafe_allow_html=True,
    )
    if rows.empty:
        st.info("조건에 맞는 질문이 없습니다. 항목이나 검색어를 바꿔 보세요.")
        return

    pages = (len(rows) - 1) // PAGE_SIZE + 1
    ss.faq_page = min(max(ss.faq_page, 1), pages)
    view = rows.iloc[(ss.faq_page - 1) * PAGE_SIZE: ss.faq_page * PAGE_SIZE]
    show_insurer = ss.faq_insurer == ALL
    for _, r in view.iterrows():
        tag = f"[{r['보험사']} · {r['항목']}]" if show_insurer else f"[{r['항목']}]"
        with st.expander(md_escape(f"{tag} {r['질문']}")):
            answer = html.escape(r["답변"]).replace("\n", "<br>")
            st.markdown(
                f"<div class='faq-meta'>{html.escape(r['보험사'])} · {html.escape(r['항목'])}</div>"
                f"<div class='faq-a'>{answer}</div>",
                unsafe_allow_html=True,
            )

    if pages > 1:
        prev_col, mid_col, next_col = st.columns([1, 2, 1])

        def go(step):
            ss.faq_page += step

        prev_col.button("◀ 이전", disabled=ss.faq_page <= 1, on_click=go, args=(-1,), use_container_width=True)
        mid_col.markdown(
            f"<div style='text-align:center;padding-top:8px;color:#5B6570'>{ss.faq_page} / {pages} 페이지</div>",
            unsafe_allow_html=True,
        )
        next_col.button("다음 ▶", disabled=ss.faq_page >= pages, on_click=go, args=(1,), use_container_width=True)

    st.caption("출처: 각 보험사 홈페이지 FAQ (삼성화재, AXA손해보험, 하나손해보험, KB손해보험). 답변 내용은 수집 시점 기준이며 최신 약관과 다를 수 있습니다.")


def _load_cached(st) -> pd.DataFrame:
    @st.cache_data
    def _load() -> pd.DataFrame:
        return load_faq()

    return _load()


if __name__ == "__main__":
    faq = load_faq()
    print(faq.groupby("보험사").size())
    for ins in INSURERS:
        print(ins, categories(faq, ins))
    print(faq.sample(3, random_state=2).to_string())
    print(filter_faq(faq, ALL, ALL, "자기부담금").shape)
