"""설날 vs 추석 연휴 교통사고 분석 함수 모음.

화면(app.py)과 분리해 두어서 streamlit 없이도 계산 결과를 확인할 수 있습니다.
    python analysis.py
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

DATA_DIR = Path(__file__).parent / "data"
CSV_PATH = DATA_DIR / "holiday_accidents_2021_2025.csv"
GEO_PATH = DATA_DIR / "sido.geojson"
HOTSPOT_PATH = DATA_DIR / "hotspots_2021_2025.csv"
HOTSPOT_PERIOD = "2021~2025"  # 사고다발지역은 5년 묶음 자료 (연도·명절 구분 없음)

HOLIDAYS = ["설날", "추석"]
METRICS = {"사고": "건", "부상": "명", "사망": "명"}
WEEKDAYS = ["월", "화", "수", "목", "금", "토", "일"]
VALUE_COLS = ["사고", "사망", "중상", "부상"]


def josa(word: str, pair: str = "이가") -> str:
    """받침 유무에 맞는 조사를 붙입니다. pair: '이가', '은는', '을를', '으로로'."""
    code = ord(word[-1]) - 0xAC00
    has_final = 0 <= code <= 11171 and code % 28 != 0
    if pair == "으로로":
        return word + ("으로" if has_final and code % 28 != 8 else "로")
    return word + (pair[0] if has_final else pair[1])


# ---------------------------------------------------------------- 불러오기
def load_data(path: Path | str = CSV_PATH) -> pd.DataFrame:
    """CSV를 읽고 '일차'(연휴 몇째 날)와 '연휴일수' 컬럼을 붙입니다.

    컬럼: 연도, 명절, 날짜, 요일, 시도, 시군구, 사고, 사망, 중상, 부상
    - 시도 == '전국'  : 전국 합계 행
    - 시군구 == '소계': 시도 합계 행
    - 부상에는 중상이 포함되어 있으므로 부상 + 중상을 더하면 안 됩니다.
    """
    df = pd.read_csv(path, encoding="utf-8-sig")
    df["날짜"] = pd.to_datetime(df["날짜"])
    days = (
        df[["연도", "명절", "날짜"]]
        .drop_duplicates()
        .sort_values("날짜")
        .assign(일차=lambda d: d.groupby(["연도", "명절"]).cumcount() + 1)
    )
    days["연휴일수"] = days.groupby(["연도", "명절"])["일차"].transform("max")
    return df.merge(days, on=["연도", "명절", "날짜"], how="left")


def load_hotspots(path: Path | str = HOTSPOT_PATH) -> pd.DataFrame:
    """연휴기간 사고다발지역 (도로교통공단, 2021~2025 묶음).

    컬럼: 지점명, 시도, 시군구, 사고, 사상자, 사망, 중상, 경상, 부상신고, 경도, 위도
    사고통계는 '용인시'처럼 시 단위, 사고다발지는 '용인시처인구'처럼 구 단위라서
    필터용으로 시 이름만 남긴 '시군구_기준' 컬럼을 붙입니다.
    """
    hs = pd.read_csv(path, encoding="utf-8-sig")
    hs["시군구_기준"] = hs["시군구"].str.replace(r"^(.+?시).+구$", r"\1", regex=True)
    return hs


def hotspots_in(hs: pd.DataFrame, sido: str = "전체", sgg: str = "전체") -> pd.DataFrame:
    if sido == "전체":
        return hs
    hs = hs[hs["시도"] == sido]
    return hs if sgg == "전체" else hs[hs["시군구_기준"] == sgg]


def hotspot_values(hs: pd.DataFrame, metric: str) -> pd.Series:
    """사고다발지의 지표별 값. 사고=사고 건수, 부상=사상자−사망(중상+경상+부상신고), 사망=사망자."""
    if metric == "사고":
        return hs["사고"]
    if metric == "부상":
        return hs["사상자"] - hs["사망"]
    return hs["사망"]


def hotspot_area_stats(df: pd.DataFrame, hs: pd.DataFrame, year: int | None, metric: str) -> pd.DataFrame:
    """사고다발지 지점마다, 그 지점이 속한 시군구의 선택 연도 연휴 수치(설날·추석)를 붙입니다.

    사고다발지 자료에는 연도 구분이 없어서, 연도 필터는 '소속 시군구'의 연휴 사고통계로 연결합니다.
    (용인시처인구 → 용인시처럼 '시군구_기준'으로 사고통계의 시군구와 맞춥니다.)
    """
    r = filter_years(df[(df["시도"] != "전국") & (df["시군구"] != "소계")], year)
    t = (
        r.pivot_table(index=["시도", "시군구"], columns="명절", values=metric, aggfunc="sum")
        .reindex(columns=HOLIDAYS)
        .fillna(0)
        .rename(columns={"설날": "지역_설날", "추석": "지역_추석"})
        .reset_index()
        .rename(columns={"시군구": "시군구_기준"})
    )
    out = hs.merge(t, on=["시도", "시군구_기준"], how="left")
    out["지역_합계"] = out["지역_설날"] + out["지역_추석"]
    return out


def region_rows(df: pd.DataFrame, sido: str = "전체", sgg: str = "전체") -> pd.DataFrame:
    """선택한 지역의 행만 돌려줍니다 (합계 행을 사용해 이중 집계를 막습니다)."""
    if sido == "전체":
        return df[df["시도"] == "전국"]
    if sgg == "전체":
        return df[(df["시도"] == sido) & (df["시군구"] == "소계")]
    return df[(df["시도"] == sido) & (df["시군구"] == sgg)]


def sido_list(df: pd.DataFrame) -> list[str]:
    return sorted(s for s in df["시도"].unique() if s != "전국")


def sgg_list(df: pd.DataFrame, sido: str) -> list[str]:
    if sido == "전체":
        return []
    return sorted(df.loc[(df["시도"] == sido) & (df["시군구"] != "소계"), "시군구"].unique())


def filter_years(rows: pd.DataFrame, year: int | None) -> pd.DataFrame:
    return rows if year is None else rows[rows["연도"] == year]


# ---------------------------------------------------------------- 요약 지표
def summarize(rows: pd.DataFrame) -> pd.DataFrame:
    """명절별 합계, 연휴 일수, 일평균, 치사율을 계산합니다.

    치사율 = 사망 ÷ 사고 × 100 (사고 100건당 사망자)
    """
    g = rows.groupby("명절")
    out = g[VALUE_COLS].sum()
    out["일수"] = g["날짜"].nunique()  # 날짜에 연도가 들어 있어 여러 해를 합쳐도 겹치지 않음
    for m in METRICS:
        out[f"{m}_일평균"] = out[m] / out["일수"]
    out["치사율"] = (out["사망"] / out["사고"].where(out["사고"] > 0) * 100).fillna(0)
    return out.reindex(HOLIDAYS).fillna(0)


def yearly(rows: pd.DataFrame, metric: str, per_day: bool) -> pd.DataFrame:
    """연도 × 명절 표. per_day=True면 연휴 일수로 나눈 일평균."""
    g = rows.groupby(["연도", "명절"])
    t = g[metric].sum().to_frame("값")
    t["일수"] = g["날짜"].nunique()
    if per_day:
        t["값"] = t["값"] / t["일수"]
    return t.reset_index()


def verdict(summary: pd.DataFrame, metric: str, per_day: bool) -> dict:
    """더 위험한 명절 판정. 두 값이 같으면 winner=None."""
    col = f"{metric}_일평균" if per_day else metric
    a, b = summary.loc["설날", col], summary.loc["추석", col]
    if a == b:
        return {"winner": None, "ratio": 0.0, "설날": a, "추석": b}
    hi, lo = ("추석", "설날") if b > a else ("설날", "추석")
    hv, lv = max(a, b), min(a, b)
    ratio = (hv / lv - 1) * 100 if lv else float("inf")
    return {"winner": hi, "loser": lo, "ratio": ratio, "설날": a, "추석": b}


def previous_year_summary(rows: pd.DataFrame, year: int | None) -> pd.DataFrame | None:
    if year is None or year - 1 not in set(rows["연도"]):
        return None
    return summarize(rows[rows["연도"] == year - 1])


# ---------------------------------------------------------------- 일자별
def day_trend(rows: pd.DataFrame, metric: str) -> pd.DataFrame:
    """연휴 일차별 값. 여러 해가 섞이면 같은 일차끼리 평균을 냅니다."""
    per_day = rows.groupby(["연도", "명절", "일차", "날짜", "요일"])[metric].sum().reset_index()
    t = per_day.groupby(["명절", "일차"]).agg(값=(metric, "mean"), 연도수=("연도", "nunique")).reset_index()
    t["일차명"] = t["일차"].astype(str) + "일차"
    return t


def day_table(rows: pd.DataFrame, year: int, metric: str) -> pd.DataFrame:
    """연도 상세 화면의 일자별 표 (일차 기준으로 설날·추석을 나란히)."""
    r = rows[rows["연도"] == year]
    d = r.groupby(["명절", "일차", "날짜", "요일"])[metric].sum().reset_index()
    d["날짜(요일)"] = d["날짜"].dt.strftime("%m.%d") + " (" + d["요일"] + ")"
    wide = None
    for h in HOLIDAYS:
        part = d[d["명절"] == h][["일차", "날짜(요일)", metric]].rename(
            columns={"날짜(요일)": f"{h} 날짜", metric: f"{h} {metric}"}
        )
        wide = part if wide is None else wide.merge(part, on="일차", how="outer")
    wide = wide.sort_values("일차")
    for h in HOLIDAYS:
        wide[f"{h} {metric}"] = wide[f"{h} {metric}"].astype("Int64")
        wide[f"{h} 날짜"] = wide[f"{h} 날짜"].fillna("–")
    wide["일차"] = wide["일차"].astype(int).astype(str) + "일차"
    return wide.reset_index(drop=True)


# ---------------------------------------------------------------- 지역별
def sido_compare(df: pd.DataFrame, year: int | None, metric: str, per_day: bool) -> pd.DataFrame:
    """시도별 설날·추석 값과 차이(추석 − 설날)."""
    r = filter_years(df[(df["시도"] != "전국") & (df["시군구"] == "소계")], year)
    t = r.pivot_table(index="시도", columns="명절", values=metric, aggfunc="sum").reindex(columns=HOLIDAYS).fillna(0)
    if per_day:
        days = filter_years(df[df["시도"] == "전국"], year).groupby("명절")["날짜"].nunique()
        for h in HOLIDAYS:
            t[h] = t[h] / days.get(h, 1)
    t["차이"] = t["추석"] - t["설날"]
    return t.reset_index().sort_values("차이", ascending=False).reset_index(drop=True)


def sgg_top(df: pd.DataFrame, year: int | None, metric: str, sido: str = "전체", n: int = 10) -> pd.DataFrame:
    """시군구 TOP n (설날+추석 합계 기준)."""
    r = filter_years(df[(df["시도"] != "전국") & (df["시군구"] != "소계")], year)
    if sido != "전체":
        r = r[r["시도"] == sido]
    t = r.pivot_table(index=["시도", "시군구"], columns="명절", values=metric, aggfunc="sum").reindex(columns=HOLIDAYS).fillna(0)
    t["합계"] = t.sum(axis=1)
    t = t.sort_values("합계", ascending=False).head(n).reset_index()
    t["지역"] = t["시도"] + " " + t["시군구"]
    return t


def weekday_compare(rows: pd.DataFrame, metric: str) -> pd.DataFrame:
    """요일별 하루 평균 (요일마다 들어간 날 수가 달라 평균으로 비교)."""
    d = rows.groupby(["명절", "날짜", "요일"])[metric].sum().reset_index()
    t = d.groupby(["명절", "요일"]).agg(값=(metric, "mean"), 일수=("날짜", "nunique")).reset_index()
    t["요일"] = pd.Categorical(t["요일"], WEEKDAYS, ordered=True)
    return t.sort_values(["요일", "명절"])


# ---------------------------------------------------------------- 인사이트
def insights(rows: pd.DataFrame, metric: str) -> list[dict]:
    """인사이트 카드 3장 (보정 효과, 가장 위험한 날, 추세)."""
    unit = METRICS[metric]
    cards = []

    # 1. 총량 vs 일평균: 판정이 뒤집히는 해
    tot = yearly(rows, metric, per_day=False).pivot(index="연도", columns="명절", values="값")
    avg = yearly(rows, metric, per_day=True).pivot(index="연도", columns="명절", values="값")
    win_tot = (tot["추석"] > tot["설날"]).map({True: "추석", False: "설날"})
    win_avg = (avg["추석"] > avg["설날"]).map({True: "추석", False: "설날"})
    flips = [int(y) for y in tot.index if win_tot[y] != win_avg[y]]
    chuseok_years = int((win_avg == "추석").sum())
    body = f"{len(avg)}년 중 {chuseok_years}년은 일평균 {josa(metric)} 추석에 더 많았습니다."
    if flips:
        y = flips[0]
        body += (f" {y}년은 총량으로는 {win_tot[y]}({tot.loc[y, win_tot[y]]:,.0f}{unit})이 많지만 "
                 f"연휴 길이를 보정하면 {josa(win_avg[y])} 더 많습니다.")
    cards.append({"title": "연휴 길이를 보정하면", "body": body})

    # 2. 가장 위험한 하루
    d = rows.groupby(["연도", "명절", "날짜", "요일", "일차", "연휴일수"])[metric].sum().reset_index()
    top = d.loc[d[metric].idxmax()]
    by_day = day_trend(rows, metric)
    n_years = rows["연도"].nunique()
    common = by_day.groupby("일차").filter(lambda t: (t["연도수"] == n_years).all())  # 모든 해에 있는 일차만
    peak_day = common.groupby("일차")["값"].mean().idxmax()
    cards.append({
        "title": "가장 위험한 하루",
        "body": (f"{top['연도']}년 {top['명절']} {top['날짜']:%m월 %d일}({top['요일']}), "
                 f"연휴 {top['일차']}일차에 {metric} {josa(f'{top[metric]:,.0f}{unit}')} 나와 가장 많았습니다. "
                 f"모든 해에 있는 1~{common['일차'].max()}일차만 평균하면 {peak_day}일차가 가장 위험합니다."),
    })

    # 3. 추세
    years = sorted(avg.index)
    first, last = years[0], years[-1]
    parts = []
    for h in HOLIDAYS:
        a, b = avg.loc[first, h], avg.loc[last, h]
        parts.append(f"{h} {(b / a - 1) * 100:+.0f}%" if a else f"{h} {first}년 0이라 비교 불가")
    cards.append({
        "title": f"{first} → {last} 추세",
        "body": f"일평균 {metric} 변화: " + ", ".join(parts) + ".",
    })
    return cards


if __name__ == "__main__":
    df = load_data()
    nat = region_rows(df)
    s = summarize(nat)
    print(s[["사고", "사망", "부상", "일수", "사고_일평균", "치사율"]].round(2))
    print(verdict(s, "사고", per_day=True))
    print(yearly(nat, "부상", per_day=True).round(1))
    print(day_table(nat, 2025, "사고"))
    print(sido_compare(df, None, "사고", per_day=True).head())
    print(sgg_top(df, 2025, "사고"))
    print(weekday_compare(nat, "사고"))
    for c in insights(nat, "부상"):
        print("-", c["title"], ":", c["body"])
